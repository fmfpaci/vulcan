  virtual bool with_subquery() const
  {
    return (*ref)->with_subquery();
  }