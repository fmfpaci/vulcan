static ut64 RAnalRef_val(const void *_ref1) {
	const RAnalRef* ref1 = _ref1;
	return ref1->addr;
}