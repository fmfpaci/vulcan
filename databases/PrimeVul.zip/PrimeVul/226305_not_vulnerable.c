
void dmlp_box_del(GF_Box *s)
{
	gf_free(s);