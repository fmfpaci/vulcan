cmp_item* cmp_item_real::make_same()
{
  return new cmp_item_real();
}