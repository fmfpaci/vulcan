  virtual Item *grouping_field_transformer_for_where(THD *thd, uchar *arg)
  { return this; }