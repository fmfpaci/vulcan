static int __init big_key_init(void)
{
	return register_key_type(&key_type_big_key);
}