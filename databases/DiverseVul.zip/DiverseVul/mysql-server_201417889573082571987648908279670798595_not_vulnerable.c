bool create_partition_name(char *out, const char *in1,
                           const char *in2, uint name_variant,
                           bool translate)
{
  char transl_part_name[FN_REFLEN + 1];
  const char *transl_part;

  if (translate)
  {
    tablename_to_filename(in2, transl_part_name, FN_REFLEN);
    transl_part= transl_part_name;
  }
  else
    transl_part= in2;

  // Check if the path name for partition exceeds maximum path length.
  if (name_variant == NORMAL_PART_NAME)
  {
    if ((strlen(in1) + strlen(transl_part) + 3) > FN_REFLEN)
    {
      my_error(ER_PATH_LENGTH, MYF(0), in2);
      return true;
    }
  }
  else
    if ((strlen(in1) + strlen(transl_part) + 8) > FN_REFLEN)
    {
      my_error(ER_PATH_LENGTH, MYF(0), in2);
      return true;
    }

  if (name_variant == NORMAL_PART_NAME)
    strxnmov(out, FN_REFLEN, in1, "#P#", transl_part, NullS);
  else if (name_variant == TEMP_PART_NAME)
    strxnmov(out, FN_REFLEN, in1, "#P#", transl_part, "#TMP#", NullS);
  else if (name_variant == RENAMED_PART_NAME)
    strxnmov(out, FN_REFLEN, in1, "#P#", transl_part, "#REN#", NullS);

   return false;
}