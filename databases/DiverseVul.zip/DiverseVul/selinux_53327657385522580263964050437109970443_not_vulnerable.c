int __cil_resolve_ast_last_child_helper(struct cil_tree_node *current, void *extra_args)
{
	int rc = SEPOL_ERR;
	struct cil_args_resolve *args = extra_args;
	struct cil_tree_node *parent = NULL;

	if (current == NULL ||  extra_args == NULL) {
		goto exit;
	}

	parent = current->parent;

	if (parent->flavor == CIL_BLOCK) {
		struct cil_tree_node *n = parent->parent;
		args->block = NULL;
		while (n && n->flavor != CIL_ROOT) {
			if (n->flavor == CIL_BLOCK) {
				args->block = n;
				break;
			}
			n = n->parent;
		}
	} else if (parent->flavor == CIL_MACRO) {
		args->macro = NULL;
	} else if (parent->flavor == CIL_OPTIONAL) {
		struct cil_tree_node *n = parent->parent;
		if (((struct cil_optional *)parent->data)->enabled == CIL_FALSE) {
			*(args->changed) = CIL_TRUE;
			cil_list_append(args->disabled_optionals, CIL_NODE, parent);
		}
		args->optional = NULL;
		while (n && n->flavor != CIL_ROOT) {
			if (n->flavor == CIL_OPTIONAL) {
				args->optional = n;
				break;
			}
			n = n->parent;
		}
	} else if (parent->flavor == CIL_BOOLEANIF) {
		args->boolif = NULL;
	}

	return SEPOL_OK;

exit:
	return rc;
}