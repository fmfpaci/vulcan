static GF_DasherPeriod *dasher_new_period()
{
	GF_DasherPeriod *period;
	GF_SAFEALLOC(period, GF_DasherPeriod);
	if (period)
		period->streams = gf_list_new();
	return period;
}