static int brcmf_msgbuf_stats_read(struct seq_file *seq, void *data)
{
	return 0;
}