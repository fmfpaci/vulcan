void jas_cmprof_destroy(jas_cmprof_t *prof)
{ 
	int i;
	for (i = 0; i < JAS_CMPROF_NUMPXFORMSEQS; ++i) {
		if (prof->pxformseqs[i]) {
			jas_cmpxformseq_destroy(prof->pxformseqs[i]);
			prof->pxformseqs[i] = 0;
		}
	}
	if (prof->iccprof)
		jas_iccprof_destroy(prof->iccprof);
	jas_free(prof);
}