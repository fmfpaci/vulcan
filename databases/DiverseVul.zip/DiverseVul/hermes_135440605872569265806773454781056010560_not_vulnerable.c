  bool isASCII() const {
    return isASCII_;
  }