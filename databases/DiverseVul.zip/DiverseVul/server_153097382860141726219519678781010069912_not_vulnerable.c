  uint32 pack_length() const
  { return (uint32) (packlength + portable_sizeof_char_ptr); }