    virtual bool slaveOverrideOk() const {
        return true;
    }