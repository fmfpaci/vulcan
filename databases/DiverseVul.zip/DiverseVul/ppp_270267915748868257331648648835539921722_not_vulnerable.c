eap_success(esp, inp, id, len)
eap_state *esp;
u_char *inp;
int id;
int len;
{
	if (esp->es_client.ea_state != eapOpen && !eap_client_active(esp)) {
		dbglog("EAP unexpected success message in state %s (%d)",
		    eap_state_name(esp->es_client.ea_state),
		    esp->es_client.ea_state);
		return;
	}

	if (esp->es_client.ea_timeout > 0) {
		UNTIMEOUT(eap_client_timeout, (void *)esp);
	}

	if (len > 0) {
		/* This is odd.  The spec doesn't allow for this. */
		PRINTMSG(inp, len);
	}

	esp->es_client.ea_state = eapOpen;
	auth_withpeer_success(esp->es_unit, PPP_EAP, 0);
}