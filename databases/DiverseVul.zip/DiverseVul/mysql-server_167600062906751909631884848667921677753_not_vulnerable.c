int ha_partition::reset(void)
{
  int result= 0, tmp;
  handler **file;
  DBUG_ENTER("ha_partition::reset");
  if (m_part_info)
    bitmap_set_all(&m_part_info->used_partitions);
  file= m_file;
  do
  {
    if ((tmp= (*file)->ha_reset()))
      result= tmp;
  } while (*(++file));
  DBUG_RETURN(result);
}