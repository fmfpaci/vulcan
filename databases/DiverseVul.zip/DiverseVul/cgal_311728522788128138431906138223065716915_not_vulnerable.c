  void clear_outer_face_cycle_marks(const Tag_false&)
  {}