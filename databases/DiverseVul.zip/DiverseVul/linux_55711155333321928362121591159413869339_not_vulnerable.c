static int ecw2cw(int ecw)
{
	return (1 << ecw) - 1;
}