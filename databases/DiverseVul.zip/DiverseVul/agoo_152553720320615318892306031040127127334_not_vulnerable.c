con_ssl_error(agooCon c, const char *what, unsigned long e, const char *filename, int line) {
    char	buf[224];

    if (0 == e) {
	e = ERR_get_error();
    }
    c->dead = true;
    ERR_error_string_n(e, buf, sizeof(buf));
    agoo_log_cat(&agoo_error_cat, "%s %s at %s:%d", what, buf, filename, line);
}