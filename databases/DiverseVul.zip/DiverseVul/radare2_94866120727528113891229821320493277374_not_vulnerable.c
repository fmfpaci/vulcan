R_API void PE_(bin_pe_parse_resource)(RBinPEObj *pe) {
	int index = 0;
	ut64 off = 0, rsrc_base = pe->resource_directory_offset;
	Pe_image_resource_directory *rs_directory = pe->resource_directory;
	ut32 curRes = 0;
	int totalRes = 0;
	HtUUOptions opt = { 0 };
	HtUU *dirs = ht_uu_new_opt (&opt); //to avoid infinite loops
	if (!dirs) {
		return;
	}
	if (!rs_directory) {
		ht_uu_free (dirs);
		return;
	}
	curRes = rs_directory->NumberOfNamedEntries;
	totalRes = curRes + rs_directory->NumberOfIdEntries;
	if (totalRes > R_PE_MAX_RESOURCES) {
		eprintf ("Error parsing resource directory\n");
		ht_uu_free (dirs);
		return;
	}
	for (index = 0; index < totalRes; index++) {
		Pe_image_resource_directory_entry typeEntry;
		off = rsrc_base + sizeof (*rs_directory) + index * sizeof (typeEntry);
		ht_uu_insert (dirs, off, 1);
		if (off > pe->size || off + sizeof (typeEntry) > pe->size) {
			break;
		}
		if (read_image_resource_directory_entry (pe->b, off, &typeEntry) < 0) {
			eprintf ("Warning: read resource directory entry\n");
			break;
		}
		if (typeEntry.u2.OffsetToData >> 31) {
			Pe_image_resource_directory identEntry;
			ut32 OffsetToDirectory = typeEntry.u2.OffsetToData & 0x7fffffff;
			off = rsrc_base + OffsetToDirectory;
			int len = read_image_resource_directory (pe->b, off, &identEntry);
			if (len != sizeof (identEntry)) {
				eprintf ("Warning: parsing resource directory\n");
			}
			(void)_parse_resource_directory (pe, &identEntry, OffsetToDirectory, typeEntry.u1.Name & 0xffff, 0, dirs, NULL);
		}
	}
	ht_uu_free (dirs);
	_store_resource_sdb (pe);
}