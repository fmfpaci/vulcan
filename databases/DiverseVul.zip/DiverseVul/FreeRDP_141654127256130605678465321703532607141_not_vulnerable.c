PBYTE ntlm_av_pair_get_value_pointer(NTLM_AV_PAIR* pAvPair)
{
	return (PBYTE)pAvPair + sizeof(NTLM_AV_PAIR);
}