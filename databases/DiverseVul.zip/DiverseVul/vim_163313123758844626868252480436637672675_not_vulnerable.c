utf_ptr2cells_len(char_u *p, int size)
{
    int		c;

    // Need to convert to a wide character.
    if (size > 0 && *p >= 0x80)
    {
	if (utf_ptr2len_len(p, size) < utf8len_tab[*p])
	    return 1;  // truncated
	c = utf_ptr2char(p);
	// An illegal byte is displayed as <xx>.
	if (utf_ptr2len(p) == 1 || c == NUL)
	    return 4;
	// If the char is ASCII it must be an overlong sequence.
	if (c < 0x80)
	    return char2cells(c);
	return utf_char2cells(c);
    }
    return 1;
}