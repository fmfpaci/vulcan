roleNamesToIds(List *memberNames)
{
	List	   *result = NIL;
	ListCell   *l;

	foreach(l, memberNames)
	{
		char	   *rolename = strVal(lfirst(l));
		Oid			roleid = get_role_oid(rolename, false);

		result = lappend_oid(result, roleid);
	}
	return result;
}