  uint cursor_rowtype_offset() const
  {
    return m_cursor_rowtype_offset;
  }