JVM_ConstantPoolGetMethodAt(JNIEnv *env, jobject anObject, jobject constantPool, jint index)
{
	Trc_SC_ConstantPoolGetMethodAt(env);
	exit(209);
}