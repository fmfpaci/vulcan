TfLiteRegistration* Register_REDUCE_PROD_REF() {
  static TfLiteRegistration r = {
      reduce::Init, reduce::Free, reduce::PrepareSimple,
      reduce::EvalGeneric<reduce::kReference, reduce::kProd>};
  return &r;
}