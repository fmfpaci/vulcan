    std::string help() const override {
        return "Drops a single user.";
    }